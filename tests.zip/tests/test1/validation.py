####
# Base Validation error
##
class ValidationException(Exception):
    def __init__(self, *args, **kwargs):
        self.error_dict = kwargs.pop('error_dict', None)
        ValueError.__init__(self, *args, **kwargs)

####
# ValidatorType -- base class for all validation types
##
class ValidatorType:
    def __init__(self, *args, **kwargs):
        pass

    def to_python(self, value):
        if is_empty(value):
            return None
        return self._to_python(value)

    def _to_python(self, value):
        return value

class Integer(ValidatorType):
    def __init__(self, *args, **kwargs):
        self.min = kwargs.pop('min', None)
        self.max = kwargs.pop('max', None)

        ValidatorType.__init__(self, *args, **kwargs)

    def _to_python(self, value):
        try:
            value = int(value)
        except ValueError, e:
            raise ValidationException('invalid value')

        if self.min and value < self.min:
            raise ValidationException('value must not be less than %d' % self.min)

        if self.max and value > self.max:
            raise ValidationException('value must not be greater than %d' % self.max)

        return value

class String(ValidatorType):
    def __init__(self, length, *args, **kwargs):
        self.length = length
        ValidatorType.__init__(self, *args, **kwargs)
    
    def _to_python(self, value):
        ## TODO: implement this
        return value

class Email(ValidatorType):
    def _to_python(self,value):
        ## TODO: implement this
        return value

class FormField:
    def __init__(self, type=None, name=None, empty=False):
        self.name = name
        self.type = type
        self.empty = empty

    def get_default(self):
        return None

    def to_python(self, value):
        if self.type:
            value = self.type.to_python(value)
        return value

class FieldExtractor(type):
    def __init__(cls, classname, bases, dict):
        type.__init__(cls, classname, bases, dict)

        cls._fields = {}

        for k,v in dict.items():
            if isinstance(v, FormField):
                v.name = v.name or k
                cls._fields[k] = v

class FormProcessor(object):
    __metaclass__ = FieldExtractor

    def __init__(self, form_name=None):
        self.form_name = form_name
        object.__init__(self)

    def __validate_fields(self, values):
        errors = {}
        ## TODO: implement field level validation based 
        ## on the values passed in
        return (values, errors)    

    def process(self, values):
        if self.form_name is not None and ('__form_name' not in values or values['__form_name'] != self.form_name):
            return None
        (values, errors) = self.__validate_fields(values)

        if errors:
            raise ValidationException(error_dict=errors)
        return values

class MyFormProcessor(FormProcessor):
    first_name = FormField(String(16))
    last_name = FormField(String(16))
    email = FormField(Email())
    age = FormField(Integer(min=18))

if __name__ == '__main__':
    mfp = MyFormProcessor()
    print mfp.process({'first_name':'dave',
                       'last_name':'smith',
                       'email':'dave.smith@email.com',
                       'age':'32'})
